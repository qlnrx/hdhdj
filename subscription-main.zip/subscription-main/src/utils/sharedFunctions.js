const mongoose = require('mongoose');
const Resources = require('../Resource');
const Ticket = require('../schemas/Ticket');
const GameBot = require('../schemas/GameBot');
const SystemBot = require('../schemas/SystemBot');
const ZajilBot = require('../schemas/ZajilBot');
const BroadcastBot = require('../schemas/BroadcastBot');
const Protection = require('../schemas/Protection');
const Feedback = require('../schemas/Feedback');

// Fetch user subscriptions from MongoDB
async function fetchUserSubscriptions(userId) {
  try {
    const subscriptions = await Promise.all([
      Ticket.findOne({ userId }),
      GameBot.findOne({ userId }),
      SystemBot.findOne({ userId }),
      ZajilBot.findOne({ userId }),
      BroadcastBot.findOne({ userId }),
      Protection.findOne({ userId }),
      Feedback.findOne({ userId }),
    ]);

    return subscriptions.filter(sub => sub !== null).map(sub => ({
      botType: sub.constructor.modelName,
      duration: sub.duration,
      createdAt: sub.createdAt,
      status: (new Date(sub.createdAt) + sub.duration > Date.now()) ? 'active' : 'expired', // Check active status
    }));
  } catch (error) {
    console.error('Error fetching subscriptions:', error);
    throw new Error('Could not fetch subscriptions. Please try again later.'); // Error handling
  }
}

// Add a new subscription based on selected bot type
async function addSubscription(userId, botType, amount, serverId, duration) {
  const schema = getSchemaByBotType(botType);

  if (!schema) throw new Error('Invalid bot type');

  const newSubscription = new schema({
    userId,
    botType,
    amount,
    serverId,
    duration,
    createdAt: new Date(),
  });

  await newSubscription.save();
}

// Verify PayPal transaction
async function verifyTransaction(email, expectedAmount) {
  try {
    const url = `https://api.paypal.com/v1/payments/payment?email=${email}&amount=${expectedAmount}`;
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${process.env.PAYPAL_SECRET}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`PayPal API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.state === 'completed';
  } catch (error) {
    console.error('Transaction verification failed:', error);
    throw new Error('Payment verification failed. Please try again later.'); // Error handling
  }
}

// Send bot links to the user after verification
async function sendBotLinks(interaction, botType) {
  const botLinks = Resources.BOT_LINKS[botType];

  if (!botLinks) {
    await interaction.reply({ content: 'No links available for this bot type.', ephemeral: true });
    return;
  }

  await interaction.user.send(`Here are your links for ${botType}: ${botLinks}`);
}

// Get the appropriate schema based on bot type
function getSchemaByBotType(botType) {
  switch (botType) {
    case 'ticket_bot':
      return Ticket;
    case 'game_bot':
      return GameBot;
    case 'system_bot':
      return SystemBot;
    case 'zajil_bot':
      return ZajilBot;
    case 'broadcast_bot':
      return BroadcastBot;
    case 'protection_bot':
      return Protection;
    case 'feedback_bot':
      return Feedback;
    default:
      return null;
  }
}

module.exports = {
  fetchUserSubscriptions,
  addSubscription,
  verifyTransaction,
  sendBotLinks,
};
