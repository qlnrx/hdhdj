const fetch = require('node-fetch');
const { Ticket, GameBot, SystemBot, ZajilBot, BroadcastBot, Protection, Feedback } = require('../schemas');

async function verifyRenewal(email, expectedAmount) {
  try {
    const url = `https://api.paypal.com/v1/payments/payment?email=${email}&amount=${expectedAmount}`;
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${process.env.PAYPAL_SECRET}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`PayPal API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.state === 'completed';
  } catch (error) {
    console.error('Renewal verification failed:', error);
    throw new Error('Renewal verification failed. Please try again later.');
  }
}

module.exports = { verifyRenewal };
