module.exports = {
    PAYPAL_EMAIL: 'sherifarafa9494@gmail.com',
    BOT_LINKS: {
      ticket_bot: 'https://discord.com/oauth2/authorize?client_id=TICKET_BOT_CLIENT_ID&scope=bot',
      game_bot: 'https://discord.com/oauth2/authorize?client_id=GAME_BOT_CLIENT_ID&scope=bot',
      system_bot: 'https://discord.com/oauth2/authorize?client_id=SYSTEM_BOT_CLIENT_ID&scope=bot',
      zajil_bot: 'https://discord.com/oauth2/authorize?client_id=ZAJIL_BOT_CLIENT_ID&scope=bot',
      broadcast_bot: 'https://discord.com/oauth2/authorize?client_id=BROADCAST_BOT_CLIENT_ID&scope=bot',
      protection_bot: 'https://discord.com/oauth2/authorize?client_id=PROTECTION_BOT_CLIENT_ID&scope=bot',
      feedback_bot: 'https://discord.com/oauth2/authorize?client_id=FEEDBACK_BOT_CLIENT_ID&scope=bot',
    },
  };
  