const mongoose = require('mongoose');

const systemBotSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  botType: { type: String, default: 'SystemBot' },
  duration: { type: Number, required: true },
  createdAt: { type: Date, default: Date.now },
  expiresAt: { type: Date, required: true },
  serverId: { type: String, required: true },
});

systemBotSchema.pre('save', function(next) {
  this.expiresAt = new Date(this.createdAt.getTime() + this.duration * 24 * 60 * 60 * 1000);
  next();
});

systemBotSchema.methods.checkExpiration = function() {
  const now = new Date();
  if (now > this.expiresAt) {
    this.duration = 0; // Reset duration to zero
  }
};

const SystemBot = mongoose.model('SystemBot', systemBotSchema);

module.exports = SystemBot;
