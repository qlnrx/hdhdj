const mongoose = require('mongoose');

const feedbackSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  botType: { type: String, default: 'Feedback' },
  duration: { type: Number, required: true },
  createdAt: { type: Date, default: Date.now },
  expiresAt: { type: Date, required: true },
  serverId: { type: String, required: true },
});

feedbackSchema.pre('save', function(next) {
  this.expiresAt = new Date(this.createdAt.getTime() + this.duration * 24 * 60 * 60 * 1000);
  next();
});

feedbackSchema.methods.checkExpiration = function() {
  const now = new Date();
  if (now > this.expiresAt) {
    this.duration = 0; // Reset duration to zero
  }
};

const Feedback = mongoose.model('Feedback', feedbackSchema);

module.exports = Feedback;
