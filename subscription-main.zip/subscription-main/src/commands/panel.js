const {
  ChatInputCommandInteraction,
  ButtonBuilder,
  ActionRowBuilder,
  ButtonStyle,
} = require('discord.js');

module.exports = {
  data: {
    name: 'panel',
    description: 'Subscription panel with options.',
  },

  run: async ({ interaction }) => {
    if (!interaction.isCommand()) return;

    try {
      await interaction.deferReply();

      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('buy')
            .setLabel('Buy')
            .setStyle(ButtonStyle.Primary),
          new ButtonBuilder()
            .setCustomId('my_subscriptions')
            .setLabel('My Subscriptions')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('renew_subscription')
            .setLabel('Renew Subscription')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId('tips')
            .setLabel('Tips/Explanation')
            .setStyle(ButtonStyle.Primary),
        );

      await interaction.editReply({
        content: 'Choose an option:',
        components: [row],
      });
    } catch (error) {
      console.error('Error executing panel command:', error);
      if (interaction.deferred || interaction.replied) {
        await interaction.followUp({ content: 'There was an error executing the command.', ephemeral: true });
      } else {
        await interaction.reply({ content: 'There was an error executing the command.', ephemeral: true });
      }
    }
  },
};
