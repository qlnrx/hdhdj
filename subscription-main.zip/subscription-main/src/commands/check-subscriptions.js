const { ApplicationCommandOptionType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const Ticket = require('../schemas/Ticket');
const GameBot = require('../schemas/GameBot');
const SystemBot = require('../schemas/SystemBot');
const ZajilBot = require('../schemas/ZajilBot');
const BroadcastBot = require('../schemas/BroadcastBot');
const Protection = require('../schemas/Protection');
const Feedback = require('../schemas/Feedback');

module.exports = {
  run: async ({ interaction }) => {
    try {
      const clientId = interaction.options.getUser('client')?.id || interaction.user.id;
      const schemas = [Ticket, GameBot, SystemBot, ZajilBot, BroadcastBot, Protection, Feedback];
      
      const subscriptions = await Promise.all(schemas.map(async (schema) => {
        try {
          return await schema.findOne({ userId: clientId });
        } catch (err) {
          console.error(`Error fetching subscription from ${schema.modelName}:`, err);
          return null;
        }
      }));

      const validSubscriptions = subscriptions.filter(subscription => subscription !== null);

      if (validSubscriptions.length === 0) {
        await interaction.reply({ content: 'You have no active subscriptions.', ephemeral: true });
        return;
      }

      // If the user has only one subscription
      if (validSubscriptions.length === 1) {
        const embed = createEmbed(validSubscriptions[0], clientId);
        await interaction.reply({ embeds: [embed], ephemeral: true });

        // Wait for two minutes and then delete the message
        setTimeout(async () => {
          try {
            await interaction.deleteReply(); // Delete the message after two minutes
          } catch (err) {
            console.error('Error deleting reply:', err);
          }
        }, 120000); // 120000 milliseconds = two minutes

        return; // End the function here
      }

      let currentIndex = 0;
      const embed = createEmbed(validSubscriptions[currentIndex], clientId);
      const row = createActionRow(currentIndex, validSubscriptions.length);
      const message = await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });

      const collector = message.createMessageComponentCollector({ time: 60000 });

      collector.on('collect', async (buttonInteraction) => {
        if (buttonInteraction.user.id !== interaction.user.id) {
          return buttonInteraction.reply({ content: 'You cannot use these buttons.', ephemeral: true });
        }

        await buttonInteraction.deferUpdate(); // Defer the update first

        try {
          if (buttonInteraction.customId === 'next' && currentIndex < validSubscriptions.length - 1) {
            currentIndex++;
          } else if (buttonInteraction.customId === 'back' && currentIndex > 0) {
            currentIndex--;
          }

          const newEmbed = createEmbed(validSubscriptions[currentIndex], clientId);
          const newRow = createActionRow(currentIndex, validSubscriptions.length);
          
          // Use editReply instead of update
          await buttonInteraction.editReply({ embeds: [newEmbed], components: [newRow] });
        } catch (err) {
          console.error(err);
        }
      });

      collector.on('end', async () => {
        await message.edit({ components: [] }); // Disable buttons after time runs out
      });

    } catch (error) {
      await interaction.reply({ content: `There was an error checking subscriptions: ${error.message}`, ephemeral: true });
    }
  },

  data: {
    name: 'check-subscriptions',
    description: 'Check the active subscriptions of a user.',
    options: [
      {
        name: 'client',
        description: 'Mention the user to check subscriptions for (optional)',
        type: ApplicationCommandOptionType.User,
        required: false,
      },
    ],
  },
};

function createEmbed(subscription, clientId) {
  if (!subscription) return new EmbedBuilder().setDescription('No subscription found.');

  const durationDays = subscription.duration;
  const createdAt = new Date(subscription.createdAt).toDateString();
  const expiresAt = new Date(subscription.expiresAt).toDateString();
  const botType = subscription.botType || 'Unknown';
  const serverId = subscription.serverId || 'Unknown';

  const today = new Date();
  const expiresAtDate = new Date(subscription.expiresAt);
  const timeDiff = expiresAtDate - today;
  const daysRemaining = Math.ceil(timeDiff / (1000 * 3600 * 24));

  return new EmbedBuilder()
    .setTitle(`Subscription Status for <@${clientId}>`)
    .setColor('Blue')
    .addFields(
      {
        name: 'Subscription Details',
        value: `**Status:** Active\n**Bot Type:** ${botType}\n**Server ID:** ${serverId}\n**Duration:** ${durationDays} days\n**Started On:** ${createdAt}\n**Expires On:** ${expiresAt}\n**Days Remaining:** ${daysRemaining} days`,
      }
    );
}

function createActionRow(currentIndex, total) {
  const row = new ActionRowBuilder();

  if (currentIndex > 0) {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId('back')
        .setLabel('Back')
        .setStyle(ButtonStyle.Primary),
    );
  }

  if (currentIndex < total - 1) {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId('next')
        .setLabel('Next')
        .setStyle(ButtonStyle.Primary),
    );
  }

  return row;
}
