const { ApplicationCommandOptionType, ChatInputCommandInteraction, EmbedBuilder } = require('discord.js');
const Ticket = require('../schemas/Ticket');
const GameBot = require('../schemas/GameBot');
const SystemBot = require('../schemas/SystemBot');
const ZajilBot = require('../schemas/ZajilBot');
const BroadcastBot = require('../schemas/BroadcastBot');
const Protection = require('../schemas/Protection');
const Feedback = require('../schemas/Feedback');

module.exports = {
  /**
   * @param {Object} param0
   * @param {ChatInputCommandInteraction} param0.interaction
   */
  run: async ({ interaction }) => {
    // Check if the user has admin permissions
    if (!interaction.member.permissions.has('ADMINISTRATOR')) {
      return interaction.reply({ content: 'You do not have permission to use this command.', ephemeral: true });
    }

    try {
      const clientId = interaction.options.getUser('client').id;
      const botType = interaction.options.getString('bot_type');
      const duration = interaction.options.getString('duration');
      const serverId = interaction.options.getString('server_id');

      // Convert selected duration to days
      let additionalDays = duration === 'month' ? 30 : duration === '3_months' ? 90 : 365;

      // Determine the correct model based on bot type
      let subscriptionModel;
      switch (botType) {
        case 'ticket':
          subscriptionModel = Ticket;
          break;
        case 'game_bot':
          subscriptionModel = GameBot;
          break;
        case 'system_bot':
          subscriptionModel = SystemBot;
          break;
        case 'zajil_bot':
          subscriptionModel = ZajilBot;
          break;
        case 'broadcast_bot':
          subscriptionModel = BroadcastBot;
          break;
        case 'protection':
          subscriptionModel = Protection;
          break;
        case 'feedback':
          subscriptionModel = Feedback;
          break;
        default:
          return interaction.reply({ content: 'Invalid bot type selected.', ephemeral: true });
      }

      // Find existing subscription for the specific server
      const existingSubscription = await subscriptionModel.findOne({ userId: clientId, serverId: serverId });

      if (!existingSubscription) {
        return interaction.reply({ content: 'User does not have an active subscription for this bot type in the specified server.', ephemeral: true });
      }

      // Check if the current subscription is expired and reset duration to zero if it is
      if (existingSubscription.expiresAt < new Date()) {
        existingSubscription.duration = 0; // Reset duration if expired
      }

      // Add the additional duration to the existing duration
      existingSubscription.duration += additionalDays;

      // Update the expiration date
      existingSubscription.expiresAt = new Date(existingSubscription.createdAt.getTime() + existingSubscription.duration * 24 * 60 * 60 * 1000);

      // Save the updated subscription
      await existingSubscription.save();

      const embed = new EmbedBuilder()
        .setTitle('Subscription Renewed')
        .setDescription(`Successfully renewed subscription for ${botType} for user <@${clientId}> in server <${serverId}>. New duration is now ${existingSubscription.duration} days.`)
        .setColor('Green');

      await interaction.reply({ embeds: [embed] });

      // Send log to the log channel
      const logChannel = interaction.guild.channels.cache.get('1134795900594688101'); // Replace with your log channel ID
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setTitle('New Subscription Logged')
          .addFields(
            { name: 'User', value: `<@${clientId}>`, inline: true },
            { name: 'Bot Type', value: botType, inline: true },
            { name: 'Duration', value: duration, inline: true },
            { name: 'Server ID', value: serverId, inline: true },
            { name: 'Expires At', value: existingSubscription.expiresAt.toDateString(), inline: true },
            { name: 'Actioned By', value: `<@${interaction.user.id}>`, inline: true }
          )
          .setColor('Blue')
          .setTimestamp();

        await logChannel.send({ embeds: [logEmbed] });
      }

    } catch (error) {
      console.error('Error renewing subscription:', error);
      await interaction.reply({ content: 'There was an error renewing the subscription. Please try again later.', ephemeral: true });
    }
  },

  data: {
    name: 'renew-subscription',
    description: 'Renew a subscription for a user in a specific server.',
    options: [
      {
        name: 'client',
        description: 'Mention the user to renew a subscription for',
        type: ApplicationCommandOptionType.User,
        required: true,
      },
      {
        name: 'bot_type',
        description: 'Select the type of bot',
        type: ApplicationCommandOptionType.String,
        required: true,
        choices: [
          { name: 'Ticket Bot', value: 'ticket' },
          { name: 'Game Bot', value: 'game_bot' },
          { name: 'System Bot', value: 'system_bot' },
          { name: 'Zajil Bot', value: 'zajil_bot' },
          { name: 'Broadcast Bot', value: 'broadcast_bot' },
          { name: 'Protection', value: 'protection' },
          { name: 'Feedback', value: 'feedback' },
        ],
      },
      {
        name: 'duration',
        description: 'Select the duration of the renewal',
        type: ApplicationCommandOptionType.String,
        required: true,
        choices: [
          { name: '1 Month', value: 'month' },
          { name: '3 Months', value: '3_months' },
          { name: '1 Year', value: 'year' },
        ],
      },
      {
        name: 'server_id',
        description: 'Enter the server ID where the subscription is active',
        type: ApplicationCommandOptionType.String,
        required: true,
      },
    ],
  },
};
