const { ApplicationCommandOptionType, EmbedBuilder } = require('discord.js');
const Ticket = require('../schemas/Ticket');
const GameBot = require('../schemas/GameBot');
const SystemBot = require('../schemas/SystemBot');
const ZajilBot = require('../schemas/ZajilBot');
const BroadcastBot = require('../schemas/BroadcastBot');
const Protection = require('../schemas/Protection');
const Feedback = require('../schemas/Feedback');

module.exports = {
  run: async ({ interaction }) => {
    try {
      // Check if the user has admin permissions
      const member = await interaction.guild.members.fetch(interaction.user.id);
      if (!member.permissions.has('ADMINISTRATOR')) {
        return interaction.reply({ content: 'You do not have permission to use this command.', ephemeral: true });
      }

      await interaction.deferReply();

      const clientId = interaction.options.getUser('client').id;
      const botType = interaction.options.getString('bot_type');
      const duration = interaction.options.getString('duration');
      const serverId = interaction.options.getString('server_id');

      const durationDays = duration === 'month' ? 30 : duration === '3_months' ? 90 : 365;
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + durationDays);

      let subscriptionModel;
      switch (botType) {
        case 'ticket':
          subscriptionModel = Ticket;
          break;
        case 'game_bot':
          subscriptionModel = GameBot;
          break;
        case 'system_bot':
          subscriptionModel = SystemBot;
          break;
        case 'zajil_bot':
          subscriptionModel = ZajilBot;
          break;
        case 'broadcast_bot':
          subscriptionModel = BroadcastBot;
          break;
        case 'protection':
          subscriptionModel = Protection;
          break;
        case 'feedback':
          subscriptionModel = Feedback;
          break;
        default:
          return interaction.editReply({ content: 'Invalid bot type selected.', ephemeral: true });
      }

      const existingSubscription = await subscriptionModel.findOne({ userId: clientId, serverId: serverId });

      if (existingSubscription) {
        return interaction.editReply({ content: 'User already has an active subscription for this bot type in the specified server.', ephemeral: true });
      }

      const newSubscription = new subscriptionModel({
        userId: clientId,
        botType: botType,
        duration: durationDays,
        serverId: serverId,
        expiresAt: expiresAt,
      });

      await newSubscription.save();

      const embed = new EmbedBuilder()
        .setTitle('Subscription Added')
        .setDescription(`Successfully added subscription for ${botType} for user <@${clientId}> in server <${serverId}> for ${duration}.`)
        .setColor('Green');

      await interaction.editReply({ embeds: [embed] });

      // Send a detailed message to the specific channel
      const logChannelId = '1134795900594688101'; // Your channel ID
      const logChannel = interaction.client.channels.cache.get(logChannelId);

      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setTitle('New Subscription Logged')
          .addFields(
            { name: 'User', value: `<@${clientId}>`, inline: true },
            { name: 'Bot Type', value: botType, inline: true },
            { name: 'Duration', value: duration, inline: true },
            { name: 'Server ID', value: serverId, inline: true },
            { name: 'Expires At', value: expiresAt.toDateString(), inline: true },
            { name: 'Actioned By', value: `<@${interaction.user.id}>`, inline: true }
          )
          .setColor('Blue')
          .setTimestamp();

        await logChannel.send({ embeds: [logEmbed] });
      }

    } catch (error) {
      console.error('Error adding subscription:', error);
      if (!interaction.replied) {
        await interaction.editReply({ content: 'There was an error adding the subscription. Please try again later.', ephemeral: true });
      }
    }
  },

  data: {
    name: 'add-subscription',
    description: 'Add a subscription for a user in a specific server.',
    options: [
      {
        name: 'client',
        description: 'Mention the user to add a subscription for',
        type: ApplicationCommandOptionType.User,
        required: true,
      },
      {
        name: 'bot_type',
        description: 'Select the type of bot',
        type: ApplicationCommandOptionType.String,
        required: true,
        choices: [
          { name: 'Ticket Bot', value: 'ticket' },
          { name: 'Game Bot', value: 'game_bot' },
          { name: 'System Bot', value: 'system_bot' },
          { name: 'Zajil Bot', value: 'zajil_bot' },
          { name: 'Broadcast Bot', value: 'broadcast_bot' },
          { name: 'Protection', value: 'protection' },
          { name: 'Feedback', value: 'feedback' },
        ],
      },
      {
        name: 'duration',
        description: 'Select the duration of the subscription',
        type: ApplicationCommandOptionType.String,
        required: true,
        choices: [
          { name: '1 Month', value: 'month' },
          { name: '3 Months', value: '3_months' },
          { name: '1 Year', value: 'year' },
        ],
      },
      {
        name: 'server_id',
        description: 'Enter the server ID where the subscription will be active',
        type: ApplicationCommandOptionType.String,
        required: true,
      },
    ],
  },
};
