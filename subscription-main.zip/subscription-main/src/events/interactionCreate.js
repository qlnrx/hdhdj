const { Events, ActionRowBuilder, StringSelectMenuBuilder, Colors, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder, ButtonBuilder } = require('discord.js');
const {
  fetchUserSubscriptions,
  addSubscription,
  verifyTransaction,
  sendBotLinks,
} = require('../utils/sharedFunctions');
const { verifyRenewal } = require('../utils/renewFunctions');
const panelCommand = require('../commands/panel');

const LOG_CHANNEL_ID = '1134795900594688101'; // Your log channel ID

let selectedBotType;
let expectedAmount;
let paymentTimeout;
let selectedDuration;

// Function to handle the buying process
async function handleBuy(interaction) {
  if (interaction.replied || interaction.deferred) return;

  const row = new ActionRowBuilder()
    .addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('bot_selection')
        .setPlaceholder('Select a bot type')
        .addOptions([
          { label: 'Ticket Bot', value: 'ticket_bot' },
          { label: 'Game Bot', value: 'game_bot' },
          { label: 'System Bot', value: 'system_bot' },
          { label: 'Zajil Bot', value: 'zajil_bot' },
          { label: 'Broadcast Bot', value: 'broadcast_bot' },
          { label: 'Protection', value: 'protection_bot' },
          { label: 'Feedback', value: 'feedback_bot' },
        ])
    );

  await interaction.reply({ content: 'Please select a bot type:', components: [row], ephemeral: true });
}

// Handle subscription duration selection
async function handleSubscriptionDuration(interaction, botType) {
  selectedBotType = botType;

  const row = new ActionRowBuilder()
    .addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('duration_selection')
        .setPlaceholder('Select subscription duration')
        .addOptions([
          { label: '1 Month - $4', value: '1_month' },
          { label: '3 Months - $9', value: '3_months' },
          { label: '1 Year - $12', value: '1_year' },
        ])
    );

  await interaction.reply({ content: `You selected: ${botType}. Please select the subscription duration:`, components: [row], ephemeral: true });
}

// Handle payment method selection after duration selection
async function handlePaymentMethod(interaction, duration) {
  selectedDuration = duration; // Store the selected duration

  switch (duration) {
    case '1_month':
      expectedAmount = 4;
      break;
    case '3_months':
      expectedAmount = 9;
      break;
    case '1_year':
      expectedAmount = 12;
      break;
    default:
      await interaction.reply({ content: 'Invalid duration.', ephemeral: true });
      return;
  }

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('paypal_payment')
        .setLabel('PayPal')
        .setStyle(1), // PRIMARY
      new ButtonBuilder()
        .setCustomId('other_payment')
        .setLabel('Other')
        .setStyle(2) // SECONDARY
    );

  await interaction.reply({ content: `Please choose your payment method for ${selectedBotType}:`, components: [row], ephemeral: true });
}

// Modal for PayPal payment
async function showPaymentModal(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('payment_modal')
    .setTitle('PayPal Payment');

  const emailInput = new TextInputBuilder()
    .setCustomId('paypal_email')
    .setLabel('Your PayPal Email')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('example@example.com');

  const serverIdInput = new TextInputBuilder()
    .setCustomId('server_id')
    .setLabel('Your Server ID or Link')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Enter Server Link (e.g., https://discord.gg/abc123)');

  const botTypeInput = new TextInputBuilder()
    .setCustomId('selected_bot_type')
    .setLabel('Selected Bot Type')
    .setStyle(TextInputStyle.Short)
    .setValue(selectedBotType) // Set the selected bot type here
    .setPlaceholder('This will be filled automatically');

  modal.addComponents(
    new ActionRowBuilder().addComponents(emailInput),
    new ActionRowBuilder().addComponents(serverIdInput),
    new ActionRowBuilder().addComponents(botTypeInput)
  );

  await interaction.showModal(modal);
  startPaymentTimeout(interaction);
}

// Handle payment confirmation
async function handlePaymentConfirmation(interaction) {
  if (interaction.replied || interaction.deferred) return;

  const email = interaction.fields.getTextInputValue('paypal_email');
  let serverId = interaction.fields.getTextInputValue('server_id');

  // Validate and convert link to ID if it's a valid Discord invite link
  const inviteRegex = /(?:https?:\/\/)?(?:www\.)?(?:discord\.gg|discord\.com\/invite)\/([a-zA-Z0-9]+)/;
  const match = serverId.match(inviteRegex);
  if (match) {
    serverId = match[1]; // Extract the ID from the link
  } else if (!/^\d+$/.test(serverId)) {
    await interaction.reply({ content: 'Your link is invalid. Please provide a valid Discord invite link or a server ID.', ephemeral: true });
    return; // Stop the process if the ID/link is invalid
  }

  const selectedBotType = interaction.fields.getTextInputValue('selected_bot_type') || selectedBotType; // Get the bot type from modal input

  // Validate bot type before proceeding
  const validBotTypes = ['ticket_bot', 'game_bot', 'system_bot', 'zajil_bot', 'broadcast_bot', 'protection_bot', 'feedback_bot'];
  if (!validBotTypes.includes(selectedBotType)) {
    await interaction.reply({ content: 'Invalid bot type selected. Please try again.', ephemeral: true });
    return;
  }

  // Call addSubscription with duration and expiresAt
  await addSubscription(interaction.user.id, selectedBotType, expectedAmount, serverId, selectedDuration);
  const isVerified = await verifyTransaction(email, expectedAmount);

  const logChannel = await interaction.client.channels.fetch(LOG_CHANNEL_ID);
  if (logChannel) {
    const purchaseLog = `Purchase attempt by ${interaction.user.tag}:\n` +
      `Bot Type: ${selectedBotType}\n` +
      `Expected Amount: $${expectedAmount}\n` +
      `Server ID: ${serverId}\n` +
      `Timestamp: ${new Date().toLocaleString()}`;
    await logChannel.send(purchaseLog);
  }

  if (isVerified) {
    await sendBotLinks(interaction, selectedBotType);
    await interaction.reply({ content: 'Payment verified! Links sent to your DMs.', ephemeral: true });

    if (logChannel) {
      await logChannel.send(`Payment verified for ${interaction.user.tag}:\nBot Type: ${selectedBotType}\nAmount: $${expectedAmount}\nServer ID: ${serverId}`);
    }

    clearTimeout(paymentTimeout);
  } else {
    await interaction.reply({ content: 'Payment verification failed. Please try again.', ephemeral: true });

    if (logChannel) {
      await logChannel.send(`Payment verification failed for ${interaction.user.tag}:\nBot Type: ${selectedBotType}\nExpected Amount: ${expectedAmount}\nServer ID: ${serverId}`);
    }
  }
}

// Function to handle renewal process
async function handleRenew(interaction) {
  if (interaction.replied || interaction.deferred) return;

  const subscriptions = await fetchUserSubscriptions(interaction.user.id);
  if (subscriptions.length === 0) {
    await interaction.reply({ content: 'You have no active subscriptions to renew.', ephemeral: true });
    return;
  }

  const row = new ActionRowBuilder()
    .addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('renew_bot_selection')
        .setPlaceholder('Select a bot to renew')
        .addOptions(subscriptions.map(sub => ({
          label: `${sub.botType} (${sub.status})`,
          value: sub.botType,
        })))
    );

  await interaction.reply({ content: 'Please select a bot to renew:', components: [row], ephemeral: true });
}

// Handle renewal bot selection
async function handleRenewBotSelection(interaction, botType) {
  const durations = [
    { label: '1 Month - $4', value: '1_month' },
    { label: '3 Months - $9', value: '3_months' },
    { label: '1 Year - $12', value: '1_year' },
  ];

  const row = new ActionRowBuilder()
    .addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('renew_duration_selection')
        .setPlaceholder('Select renewal duration')
        .addOptions(durations)
    );

  await interaction.reply({ content: `You selected: ${botType}. Please select the renewal duration:`, components: [row], ephemeral: true });
}

// Handle renewal payment method selection
async function handleRenewPaymentMethod(interaction, duration) {
  expectedAmount = duration === '1_month' ? 4 : duration === '3_months' ? 9 : 12;

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('renew_paypal_payment')
        .setLabel('PayPal')
        .setStyle(1), // PRIMARY
      new ButtonBuilder()
        .setCustomId('renew_other_payment')
        .setLabel('Other')
        .setStyle(2) // SECONDARY
    );

  await interaction.reply({ content: `Please choose your renewal payment method for ${selectedBotType}:`, components: [row], ephemeral: true });
}

// Show renewal payment modal
async function showRenewPaymentModal(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('renew_payment_modal')
    .setTitle('Renewal Payment');

  const emailInput = new TextInputBuilder()
    .setCustomId('renew_paypal_email')
    .setLabel('Your PayPal Email')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('example@example.com');

  modal.addComponents(new ActionRowBuilder().addComponents(emailInput));

  await interaction.showModal(modal);
}

// Handle renewal payment confirmation
async function handleRenewPaymentConfirmation(interaction) {
  const email = interaction.fields.getTextInputValue('renew_paypal_email');

  const isVerified = await verifyRenewal(email, expectedAmount);
  if (isVerified) {
    await interaction.reply({ content: 'Renewal payment verified! Your subscription has been renewed.', ephemeral: true });
  } else {
    await interaction.reply({ content: 'Renewal payment verification failed. Please try again.', ephemeral: true });
  }
}

// Event Listener
module.exports = {
  name: Events.InteractionCreate,
  async execute(interaction) {
    if (interaction.isCommand() && interaction.commandName === 'panel') {
      await panelCommand.execute(interaction);
    } else if (interaction.isStringSelectMenu()) {
      if (interaction.customId === 'bot_selection') {
        const botType = interaction.values[0];
        await handleSubscriptionDuration(interaction, botType);
      } else if (interaction.customId === 'renew_bot_selection') {
        const botType = interaction.values[0];
        await handleRenewBotSelection(interaction, botType);
      } else if (interaction.customId === 'duration_selection') {
        const duration = interaction.values[0];
        await handlePaymentMethod(interaction, duration);
      } else if (interaction.customId === 'renew_duration_selection') {
        const duration = interaction.values[0];
        await handleRenewPaymentMethod(interaction, duration);
      }
    } else if (interaction.isButton()) {
      if (interaction.customId === 'paypal_payment') {
        await showPaymentModal(interaction);
      } else if (interaction.customId === 'renew_paypal_payment') {
        await showRenewPaymentModal(interaction);
      }
    } else if (interaction.isModalSubmit()) {
      if (interaction.customId === 'payment_modal') {
        await handlePaymentConfirmation(interaction);
      } else if (interaction.customId === 'renew_payment_modal') {
        await handleRenewPaymentConfirmation(interaction);
      }
    }
  },
};
                                                                                                                                        
